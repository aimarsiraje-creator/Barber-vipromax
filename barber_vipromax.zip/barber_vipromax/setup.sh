#!/usr/bin/env bash
# يجهّز التطبيقات الثلاثة: أندرويد + آيفون + ويب (PWA) ويضيف الصلاحيات والأيقونات.
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

setup_app () {
  DIR="$ROOT/apps/$1"; NAME="$2"; LABEL="$3"
  cd "$DIR"
  flutter create --org com.vipromax --project-name "$NAME" --platforms android,ios,web . >/dev/null
  python3 - "$DIR" "$LABEL" <<'PY'
import sys, re, json, pathlib
d, label = pathlib.Path(sys.argv[1]), sys.argv[2]
# ---- Android ----
m = d/'android/app/src/main/AndroidManifest.xml'
s = m.read_text(encoding='utf-8')
if 'android.permission.INTERNET' not in s:
    s = s.replace('<application', '<uses-permission android:name="android.permission.INTERNET"/>\n    <queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent></queries>\n    <application', 1)
s = re.sub(r'android:label="[^"]*"', f'android:label="{label}"', s, count=1)
m.write_text(s, encoding='utf-8')
# تعطيل فحص lint الذي يفشل في بناء الإصدار (مشكلة معروفة، لا تؤثر على التطبيق)
for gname in ('build.gradle.kts', 'build.gradle'):
    g = d/'android/app'/gname
    if g.exists():
        gs = g.read_text(encoding='utf-8')
        if 'checkReleaseBuilds' not in gs:
            if gname.endswith('.kts'):
                blk = '    lint {\n        checkReleaseBuilds = false\n        abortOnError = false\n    }\n'
            else:
                blk = '    lint {\n        checkReleaseBuilds false\n        abortOnError false\n    }\n'
            gs = re.sub(r'(\nandroid\s*\{\n)', lambda mm: mm.group(1) + blk, gs, count=1)
            g.write_text(gs, encoding='utf-8')
# ---- iOS ----
p = d/'ios/Runner/Info.plist'
s = p.read_text(encoding='utf-8')
if 'NSPhotoLibraryUsageDescription' not in s:
    add = ('<key>NSPhotoLibraryUsageDescription</key><string>لاختيار الصور</string>\n'
           '<key>LSApplicationQueriesSchemes</key><array><string>tel</string></array>\n')
    s = s.replace('</dict>\n</plist>', add + '</dict>\n</plist>')
s = re.sub(r'(<key>CFBundleDisplayName</key>\s*<string>)[^<]*', r'\g<1>' + label, s, count=1)
p.write_text(s, encoding='utf-8')
# ---- Web (PWA) ----
w = d/'web/manifest.json'
if w.exists():
    j = json.loads(w.read_text(encoding='utf-8'))
    j.update({'name': label, 'short_name': label, 'background_color': '#06201A', 'theme_color': '#06201A',
              'lang': 'ar', 'dir': 'rtl', 'display': 'standalone'})
    w.write_text(json.dumps(j, ensure_ascii=False, indent=2), encoding='utf-8')
h = d/'web/index.html'
if h.exists():
    s = h.read_text(encoding='utf-8')
    s = re.sub(r'<title>.*?</title>', f'<title>{label}</title>', s)
    s = re.sub(r'(name="apple-mobile-web-app-title" content=")[^"]*', r'\g<1>' + label, s)
    s = s.replace('<html>', '<html lang="ar" dir="rtl">', 1)
    h.write_text(s, encoding='utf-8')
PY
  mkdir -p web/icons
  cp "$ROOT/branding/Icon-192.png" "$ROOT/branding/Icon-512.png" "$ROOT/branding/Icon-maskable-192.png" "$ROOT/branding/Icon-maskable-512.png" web/icons/
  cp "$ROOT/branding/favicon.png" web/favicon.png
  flutter pub get >/dev/null
  echo "جاهز: $LABEL"
}

setup_app customer customer_app "BARBER VIPROMAX"
setup_app barber   barber_app   "BARBER VIPROMAX للحلاقين"
setup_app owner    owner_app    "BARBER VIPROMAX OWNER"
