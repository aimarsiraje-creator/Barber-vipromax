library core;

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

export 'package:supabase_flutter/supabase_flutter.dart'
    show Supabase, AuthException, PostgrestException;

// ============ الإعداد: ضع بيانات مشروع Supabase هنا (مرة واحدة لكل التطبيقات) ============
const supabaseUrl = 'PUT_YOUR_SUPABASE_URL';
const supabaseAnonKey = 'PUT_YOUR_SUPABASE_ANON_KEY';

SupabaseClient get db => Supabase.instance.client;

Future<void> bootstrap(Widget app) async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(app);
}

// ============ الألوان والثيم ============
class C {
  static const bg = Color(0xFF06201A);
  static const sf = Color(0xFF0D3329);
  static const sf2 = Color(0xFF124236);
  static const ln = Color(0xFF1F5646);
  static const gold = Color(0xFFD9A441);
  static const gold2 = Color(0xFFF0CF86);
  static const bone = Color(0xFFF4ECD9);
  static const red = Color(0xFFC8372D);
  static const mu = Color(0xFF8FB0A2);
  static const ok = Color(0xFF41C98A);
  static const ink = Color(0xFF1A1205);
}

ThemeData vpTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  OutlineInputBorder b(Color c) => OutlineInputBorder(
      borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c));
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
        primary: C.gold, onPrimary: C.ink, surface: C.sf, onSurface: C.bone, error: C.red),
    textTheme: GoogleFonts.tajawalTextTheme(base.textTheme)
        .apply(bodyColor: C.bone, displayColor: C.bone),
    appBarTheme: const AppBarTheme(backgroundColor: C.bg, elevation: 0, scrolledUnderElevation: 0),
    inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: C.sf,
        border: b(C.ln),
        enabledBorder: b(C.ln),
        focusedBorder: b(C.gold)),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: C.sf,
      indicatorColor: C.gold,
      iconTheme: WidgetStateProperty.resolveWith((s) =>
          IconThemeData(color: s.contains(WidgetState.selected) ? C.ink : C.mu)),
    ),
  );
}

class VpApp extends StatelessWidget {
  const VpApp({super.key, required this.title, required this.home});
  final String title;
  final Widget home;
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: title,
        debugShowCheckedModeBanner: false,
        theme: vpTheme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: home,
      );
}

// ============ الشعار: عمود الحلاقة داخل دائرة ذهبية ============
class Logo extends StatelessWidget {
  const Logo({super.key, this.size = 40});
  final double size;
  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size(size, size), painter: _LogoPainter());
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas cv, Size s) {
    final u = s.width / 64;
    cv.drawCircle(Offset(32 * u, 32 * u), 30 * u, Paint()..color = C.sf);
    cv.drawCircle(
        Offset(32 * u, 32 * u),
        30 * u,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3 * u
          ..color = C.gold);
    final pole = RRect.fromRectAndRadius(
        Rect.fromLTWH(25 * u, 13 * u, 14 * u, 38 * u), Radius.circular(7 * u));
    cv.save();
    cv.clipRRect(pole);
    cv.drawRect(pole.outerRect, Paint()..color = C.bone);
    for (var i = -2; i < 6; i++) {
      final y = 13 * u + i * 10 * u;
      final path = Path()
        ..moveTo(25 * u, y)
        ..lineTo(39 * u, y - 8 * u)
        ..lineTo(39 * u, y - 3 * u)
        ..lineTo(25 * u, y + 5 * u)
        ..close();
      cv.drawPath(path, Paint()..color = i.isEven ? C.red : const Color(0xFF1C4F8F));
    }
    cv.restore();
    cv.drawRRect(
        pole,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2 * u
          ..color = C.gold);
    for (final y in [9.0, 49.0]) {
      cv.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(21 * u, y * u, 22 * u, 6 * u), Radius.circular(3 * u)),
          Paint()..color = C.gold);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class BrandTitle extends StatelessWidget {
  const BrandTitle(this.sub, {super.key});
  final String sub;
  @override
  Widget build(BuildContext context) => Row(children: [
        const Logo(size: 36),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('BARBER VIPROMAX',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 2, color: C.gold2)),
          Text(sub, style: const TextStyle(fontSize: 12, color: C.mu)),
        ]),
      ]);
}

// ============ صور ============
String initial(dynamic s) => '$s'.trim().isEmpty ? '?' : '$s'.trim()[0];

class Avatar extends StatelessWidget {
  const Avatar({super.key, this.url, required this.letter, this.size = 52});
  final String? url;
  final String letter;
  final double size;
  @override
  Widget build(BuildContext context) {
    final has = url != null && url!.isNotEmpty;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: C.sf2,
        border: Border.all(color: C.gold, width: 2),
        image: has ? DecorationImage(image: NetworkImage(url!), fit: BoxFit.cover) : null,
      ),
      child: has
          ? null
          : Text(letter, style: TextStyle(fontSize: size * .4, fontWeight: FontWeight.w800, color: C.gold2)),
    );
  }
}

class ShopImage extends StatelessWidget {
  const ShopImage(this.url, {super.key, this.height = 130});
  final String? url;
  final double height;
  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        width: double.infinity,
        child: (url != null && url!.isNotEmpty)
            ? Image.network(url!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _ph())
            : _ph(),
      );
  Widget _ph() => Container(color: C.sf2, child: const Center(child: Icon(Icons.storefront, color: C.gold, size: 42)));
}

class PhotoField extends StatefulWidget {
  const PhotoField({super.key, required this.label, required this.onPicked});
  final String label;
  final void Function(Uint8List bytes) onPicked;
  @override
  State<PhotoField> createState() => _PhotoFieldState();
}

class _PhotoFieldState extends State<PhotoField> {
  Uint8List? bytes;
  Future<void> pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 80);
    if (x == null) return;
    final b = await x.readAsBytes();
    setState(() => bytes = b);
    widget.onPicked(b);
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: pick,
        child: Container(
          height: 110,
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: C.sf,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: C.gold),
            image: bytes != null ? DecorationImage(image: MemoryImage(bytes!), fit: BoxFit.cover) : null,
          ),
          child: bytes != null
              ? null
              : Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.add_a_photo, color: C.gold2),
                  const SizedBox(height: 6),
                  Text(widget.label, style: const TextStyle(color: C.gold2)),
                ])),
        ),
      );
}

Future<String> uploadPhoto(Uint8List bytes, String tag) async {
  final uid = db.auth.currentUser!.id;
  final path = '$uid/$tag-${DateTime.now().millisecondsSinceEpoch}.jpg';
  await db.storage.from('vp-photos').uploadBinary(path, bytes,
      fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true));
  return db.storage.from('vp-photos').getPublicUrl(path);
}

// ============ عناصر واجهة ============
class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.onTap});
  final Widget child;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: C.sf, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.ln)),
          child: child,
        ),
      );
}

class GoldButton extends StatelessWidget {
  const GoldButton(this.label, this.onPressed,
      {super.key, this.busy = false, this.outline = false, this.danger = false});
  final String label;
  final VoidCallback? onPressed;
  final bool busy, outline, danger;
  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(14));
    final txt = busy
        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
        : Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800));
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: outline
          ? OutlinedButton(
              style: OutlinedButton.styleFrom(
                  shape: shape, foregroundColor: C.gold2, side: const BorderSide(color: C.gold)),
              onPressed: busy ? null : onPressed,
              child: txt)
          : FilledButton(
              style: FilledButton.styleFrom(
                  shape: shape,
                  backgroundColor: danger ? const Color(0x33C8372D) : C.gold,
                  foregroundColor: danger ? const Color(0xFFFF8A7D) : C.ink),
              onPressed: busy ? null : onPressed,
              child: txt),
    );
  }
}

class Field extends StatelessWidget {
  const Field(this.label, this.c, {super.key, this.keyboard, this.obscure = false});
  final String label;
  final TextEditingController c;
  final TextInputType? keyboard;
  final bool obscure;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
            controller: c, keyboardType: keyboard, obscureText: obscure, decoration: InputDecoration(labelText: label)),
      );
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.s, {super.key});
  final String s;
  static const _t = {
    'pending': 'بانتظار القبول',
    'accepted': 'مؤكد',
    'completed': 'اكتملت',
    'rejected': 'مرفوض',
    'cancelled': 'ملغى',
    'approved': 'معتمد',
    'blocked': 'موقوف',
  };
  @override
  Widget build(BuildContext context) {
    final good = s == 'accepted' || s == 'completed' || s == 'approved';
    final bad = s == 'rejected' || s == 'cancelled' || s == 'blocked';
    final col = good ? C.ok : (bad ? const Color(0xFFFF8A7D) : C.gold2);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: col.withValues(alpha: .15), borderRadius: BorderRadius.circular(10)),
      child: Text(_t[s] ?? s, style: TextStyle(color: col, fontSize: 12, fontWeight: FontWeight.w800)),
    );
  }
}

class PhoneLink extends StatelessWidget {
  const PhoneLink(this.phone, {super.key});
  final String phone;
  @override
  Widget build(BuildContext context) => TextButton.icon(
        onPressed: phone.isEmpty ? null : () => callPhone(phone),
        icon: const Icon(Icons.call, size: 18, color: C.gold2),
        label: Text(phone, textDirection: TextDirection.ltr, style: const TextStyle(color: C.gold2)),
      );
}

// ============ دوال مساعدة ============
String money(num n) =>
    '${n.toInt().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',')} دج';

String fmtDt(dynamic iso) {
  final d = DateTime.parse('$iso').toLocal();
  String p(int n) => n.toString().padLeft(2, '0');
  return '${d.day}/${d.month} - ${p(d.hour)}:${p(d.minute)}';
}

Future<void> callPhone(String p) => launchUrl(Uri(scheme: 'tel', path: p.replaceAll(' ', '')));

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

String errText(Object e) {
  if (e is AuthException) return e.message;
  if (e is PostgrestException) return e.message;
  return '$e';
}

/// ينفّذ عملية ويعرض الخطأ إن وُجد
Future<bool> run(BuildContext c, Future<dynamic> Function() f, {String? ok}) async {
  try {
    await f();
    if (ok != null && c.mounted) snack(c, ok);
    return true;
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
    return false;
  }
}
