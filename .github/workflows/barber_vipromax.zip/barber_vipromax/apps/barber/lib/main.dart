import 'dart:async';
import 'dart:typed_data';

import 'package:core/core.dart';
import 'package:flutter/material.dart';

void main() => bootstrap(const VpApp(title: 'BARBER VIPROMAX للحلاقين', home: Gate()));

// ============ بوابة: تسجيل / انتظار موافقة المالك / التطبيق ============
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Stream<List<Map<String, dynamic>>>? _s;
  String? _uid;

  @override
  Widget build(BuildContext context) {
    final u = db.auth.currentUser;
    if (u == null) return AuthScreen(onDone: () => setState(() {}));
    if (_uid != u.id) {
      _uid = u.id;
      _s = db.from('vp_barbers').stream(primaryKey: ['id']).eq('user_id', u.id);
    }
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _s,
      builder: (c, s) {
        if (!s.hasData) return const Scaffold(body: Center(child: Logo(size: 90)));
        if (s.data!.isEmpty) return AuthScreen(onDone: () => setState(() {}));
        final b = s.data!.first;
        if (b['status'] == 'approved') return BarberHome(b: b, onLogout: _logout);
        return StatusScreen(b: b, onLogout: _logout);
      },
    );
  }

  Future<void> _logout() async {
    await db.auth.signOut();
    if (mounted) setState(() => _uid = null);
  }
}

// ============ التسجيل: اسم المحل + اسم الحلاق + صور + هاتف + عنوان ============
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.onDone});
  final VoidCallback onDone;
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool reg = true, busy = false;
  final phone = TextEditingController(), pass = TextEditingController();
  final name = TextEditingController(), shop = TextEditingController(), addr = TextEditingController();
  Uint8List? bp, sp;

  String get digits => phone.text.replaceAll(RegExp(r'\D'), '');
  String get email => '$digits@barber.vipromax.app';

  Future<void> go() async {
    if (digits.length < 9 || pass.text.length < 6) {
      snack(context, 'أدخل رقم هاتف صحيح وكلمة سر من 6 أحرف على الأقل');
      return;
    }
    if (reg && (name.text.trim().isEmpty || shop.text.trim().isEmpty || addr.text.trim().isEmpty)) {
      snack(context, 'أكمل اسم الحلاق واسم المحل والعنوان');
      return;
    }
    setState(() => busy = true);
    try {
      if (reg) {
        try {
          final r = await db.auth.signUp(email: email, password: pass.text);
          if (r.session == null) throw 'فعّل تسجيل الدخول بدون تأكيد البريد في إعدادات Supabase';
        } on AuthException {
          await db.auth.signInWithPassword(email: email, password: pass.text);
        }
        String? bu, su;
        if (bp != null) bu = await uploadPhoto(bp!, 'barber');
        if (sp != null) su = await uploadPhoto(sp!, 'shop');
        await db.rpc('vp_register_barber', params: {
          'p_name': name.text.trim(),
          'p_shop': shop.text.trim(),
          'p_phone': phone.text.trim(),
          'p_address': addr.text.trim(),
          'p_bphoto': bu,
          'p_sphoto': su,
        });
      } else {
        await db.auth.signInWithPassword(email: email, password: pass.text);
      }
      widget.onDone();
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 10),
            const Center(child: Logo(size: 90)),
            const SizedBox(height: 8),
            const Center(
                child: Text('BARBER VIPROMAX',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, letterSpacing: 3, color: C.gold2))),
            const Center(child: Text('تطبيق الحلاقين', style: TextStyle(color: C.mu))),
            const SizedBox(height: 18),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('حلاق جديد')),
                ButtonSegment(value: false, label: Text('دخول')),
              ],
              selected: {reg},
              onSelectionChanged: (v) => setState(() => reg = v.first),
            ),
            const SizedBox(height: 16),
            if (reg) ...[
              Field('اسم الحلاق', name),
              Field('اسم المحل', shop),
              Field('العنوان', addr),
            ],
            Field('رقم الهاتف', phone, keyboard: TextInputType.phone),
            Field('كلمة السر', pass, obscure: true),
            if (reg) ...[
              PhotoField(label: 'صورة الحلاق', onPicked: (b) => bp = b),
              PhotoField(label: 'صورة المحل', onPicked: (b) => sp = b),
            ],
            GoldButton(reg ? 'إرسال طلب الانضمام' : 'دخول', go, busy: busy),
          ]),
        ),
      );
}

class StatusScreen extends StatelessWidget {
  const StatusScreen({super.key, required this.b, required this.onLogout});
  final Map<String, dynamic> b;
  final VoidCallback onLogout;
  @override
  Widget build(BuildContext context) {
    final st = '${b['status']}';
    final msg = st == 'pending'
        ? 'طلبك وصل إلى المالك. ستظهر للزبائن فور موافقته، وستتغير هذه الشاشة تلقائيًا.'
        : st == 'rejected'
            ? 'تم رفض طلب انضمامك. تواصل مع المالك لمعرفة السبب.'
            : 'حسابك موقوف حاليًا. تواصل مع المالك لإعادة التفعيل.';
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Logo(size: 90),
            const SizedBox(height: 24),
            StatusChip(st),
            const SizedBox(height: 14),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.6)),
            const SizedBox(height: 28),
            GoldButton('تسجيل الخروج', onLogout, outline: true),
          ]),
        ),
      ),
    );
  }
}

// ============ التطبيق الرئيسي ============
class BarberHome extends StatefulWidget {
  const BarberHome({super.key, required this.b, required this.onLogout});
  final Map<String, dynamic> b;
  final VoidCallback onLogout;
  @override
  State<BarberHome> createState() => _BarberHomeState();
}

class _BarberHomeState extends State<BarberHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final b = widget.b;
    final pages = [Requests(b: b), Finance(b: b), Profile(b: b, onLogout: widget.onLogout)];
    return Scaffold(
      appBar: AppBar(title: BrandTitle('${b['shop_name']}')),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.inbox), label: 'الطلبات'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'الأرباح'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'ملفي'),
        ],
      ),
    );
  }
}

// ============ الطلبات (تحديث مباشر + تنبيه عند وصول طلب جديد) ============
class Requests extends StatefulWidget {
  const Requests({super.key, required this.b});
  final Map<String, dynamic> b;
  @override
  State<Requests> createState() => _RequestsState();
}

class _RequestsState extends State<Requests> {
  late final Stream<List<Map<String, dynamic>>> stream =
      db.from('vp_bookings').stream(primaryKey: ['id']).eq('barber_id', widget.b['id']);
  final known = <String>{};
  bool first = true;

  Future<void> walkin() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: C.sf,
              title: const Text('زبون بدون حجز'),
              content: Field('اسم الزبون (اختياري)', c),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
                TextButton(onPressed: () => Navigator.pop(context, c.text), child: const Text('تسجيل')),
              ],
            ));
    if (name == null || !mounted) return;
    await run(context, () => db.rpc('vp_create_walkin', params: {'p_name': name}), ok: 'تم تسجيل الزبون');
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: stream,
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final all = s.data!;
          for (final k in all) {
            final id = '${k['id']}';
            if (!first && !known.contains(id) && k['status'] == 'pending' && k['source'] == 'app') {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) snack(context, 'طلب حجز جديد من ${k['customer_name']}');
              });
            }
            known.add(id);
          }
          first = false;
          final l = all.where((k) => k['status'] == 'pending' || k['status'] == 'accepted').toList()
            ..sort((a, b) => '${a['scheduled_at']}'.compareTo('${b['scheduled_at']}'));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Panel(
                child: Row(children: [
              Expanded(
                  child: Text(widget.b['is_available'] == true ? 'أنت متاح للحجز' : 'أنت مغلق',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
              Switch(
                  value: widget.b['is_available'] == true,
                  activeColor: C.ok,
                  onChanged: (v) => run(context,
                      () => db.from('vp_barbers').update({'is_available': v}).eq('id', widget.b['id']))),
            ])),
            GoldButton('تسجيل زبون بدون حجز', walkin, outline: true),
            const SizedBox(height: 16),
            const Text('الطلبات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (l.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد طلبات حاليًا'))),
            for (final k in l) _tile(k),
          ]);
        },
      );

  Widget _tile(Map<String, dynamic> k) {
    final st = '${k['status']}', id = '${k['id']}';
    return Panel(
      child: Column(children: [
        Row(children: [
          Avatar(url: k['customer_photo_url'] as String?, letter: initial(k['customer_name']), size: 48),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${k['customer_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            Text(k['source'] == 'walkin' ? 'بدون حجز' : fmtDt(k['scheduled_at']),
                style: const TextStyle(color: C.mu), textDirection: TextDirection.ltr),
          ])),
          StatusChip(st),
        ]),
        if ('${k['customer_phone']}'.isNotEmpty) Align(alignment: AlignmentDirectional.centerStart, child: PhoneLink('${k['customer_phone']}')),
        const SizedBox(height: 8),
        if (st == 'pending')
          Row(children: [
            Expanded(
                child: GoldButton('قبول',
                    () => run(context, () => db.rpc('vp_respond_booking', params: {'p_booking': id, 'p_accept': true}),
                        ok: 'تم قبول الحجز'))),
            const SizedBox(width: 10),
            Expanded(
                child: GoldButton('رفض',
                    () => run(context, () => db.rpc('vp_respond_booking', params: {'p_booking': id, 'p_accept': false}),
                        ok: 'تم رفض الحجز'),
                    danger: true)),
          ])
        else
          GoldButton('إتمام الخدمة',
              () => run(context, () => db.rpc('vp_complete_booking', params: {'p_booking': id}),
                  ok: 'اكتملت الخدمة: 1,000 دج لك')),
      ]),
    );
  }
}

// ============ الأرباح: الحلاق يرى حساباته فقط ============
class Finance extends StatefulWidget {
  const Finance({super.key, required this.b});
  final Map<String, dynamic> b;
  @override
  State<Finance> createState() => _FinanceState();
}

class _FinanceState extends State<Finance> {
  late Future<Map<String, dynamic>> f = _load();
  Future<Map<String, dynamic>> _load() async {
    final fin = await db.from('vp_finance').select().eq('barber_id', widget.b['id']).maybeSingle();
    final rows = await db.from('vp_completions').select().eq('barber_id', widget.b['id']).order('completed_at', ascending: false).limit(30);
    return {'fin': fin ?? {}, 'rows': List<Map<String, dynamic>>.from(rows)};
  }

  Widget line(String a, String b, {Color? col}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 9),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(a),
          Text(b, style: TextStyle(fontWeight: FontWeight.w800, color: col)),
        ]),
      );

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: () async {
          setState(() => f = _load());
          await f;
        },
        child: FutureBuilder<Map<String, dynamic>>(
          future: f,
          builder: (c, s) {
            if (s.hasError) return ListView(padding: const EdgeInsets.all(24), children: [Text(errText(s.error!))]);
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final fin = Map<String, dynamic>.from(s.data!['fin'] as Map);
            final rows = s.data!['rows'] as List<Map<String, dynamic>>;
            num n(String k) => (fin[k] ?? 0) as num;
            return ListView(padding: const EdgeInsets.all(16), children: [
              const Text('صافي مستحقاتك', style: TextStyle(color: C.mu)),
              Text(money(n('barber_total')),
                  style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, color: C.gold2)),
              Text('من ${n('services').toInt()} خدمة مكتملة', style: const TextStyle(color: C.mu)),
              const SizedBox(height: 16),
              Panel(
                  child: Column(children: [
                line('قيمة الخدمات الإجمالية', money(n('gross'))),
                line('مجموع خصومات المنصة', money(n('platform_total'))),
                line('ما دفعته للمالك', money(n('paid_to_owner'))),
                line('المتبقي عليك للمالك', money(n('remaining')), col: C.gold2),
              ])),
              Panel(
                  child: Column(children: [
                line('سعر الخدمة', '1,500 دج'),
                line('خصم المنصة', '− 500 دج'),
                line('لك', '1,000 دج', col: C.ok),
              ])),
              const SizedBox(height: 6),
              const Text('آخر الخدمات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final r in rows)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(fmtDt(r['completed_at']), textDirection: TextDirection.ltr),
                  trailing: Text('+ ${money(r['barber_net'] as num)}', style: const TextStyle(color: C.ok, fontWeight: FontWeight.w800)),
                ),
            ]);
          },
        ),
      );
}

// ============ ملفي ============
class Profile extends StatelessWidget {
  const Profile({super.key, required this.b, required this.onLogout});
  final Map<String, dynamic> b;
  final VoidCallback onLogout;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Stack(clipBehavior: Clip.none, children: [
          ClipRRect(borderRadius: BorderRadius.circular(20), child: ShopImage(b['shop_photo_url'] as String?, height: 170)),
          PositionedDirectional(
              end: 16,
              bottom: -34,
              child: Avatar(url: b['barber_photo_url'] as String?, letter: initial(b['barber_name']), size: 78)),
        ]),
        const SizedBox(height: 46),
        Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${b['shop_name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('الحلاق: ${b['barber_name']}'),
          Text('الهاتف: ${b['phone']}', textDirection: TextDirection.ltr),
          Text('العنوان: ${b['address']}'),
        ])),
        GoldButton('تسجيل الخروج', onLogout, outline: true),
      ]);
}
